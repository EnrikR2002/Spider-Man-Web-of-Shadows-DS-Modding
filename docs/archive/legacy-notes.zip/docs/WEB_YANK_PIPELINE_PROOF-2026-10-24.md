# First Web Yank pipeline proof

**8. Web Yank (new).** X on the ground with no native X prompt in reach: a
thick web line (red if the WebLine colour field allows; native white is 0x7FFF)
ties the nearest enemy ahead within about 45 units, and a built yank (kind
0x21) pulls it into a talon strike. Up+X builds a launch (0x25) instead.
Closer than the native Web Kick split (about 13 units), skip the pull and strike
at once. Heavy: Miguel zips to the target by velocity along the line and
strikes; holding toward it with Boarding owned starts Boarding.

