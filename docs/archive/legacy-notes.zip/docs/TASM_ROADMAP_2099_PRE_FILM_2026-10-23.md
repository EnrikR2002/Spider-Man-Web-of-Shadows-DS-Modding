## Spider-Man 2099: Black-slot rework

The player's 2026-10-22 appearance request supplies an Across the Spider-Verse
reference and explicitly removes the red web cape. They like the prior 2099
overall. This supersedes the earlier classic foundation/larger-cape direction.
The first 2026-10-23 request selects Hunter's Return and a more muscular body.
The next-skill request activates Talon Lift; the remaining five moves stay proposals.

Published v0.30.3 keeps the guarded shared-model selector and native Red list,
with Black wearing the requested cape-free navy/red movie-inspired appearance.
That appearance is the foundation for v0.32's fuller chest/arms and two private
Hunter motion clips; other native clips remain. The v0.30.3 release
also changes the shared Midnight enemy atlas from 32 KiB direct color to 8 KiB I4.
Three live enemy materials bind in the crowded Terminal capture, while the hero
retains I8. One mixed scene establishes that scene's texture binding, not
all-room residency, player visual acceptance or DeSmuME pacing. Both releases
retain native controls, ownership/progression and previous chapter work. Details
and scope are in `reference/spider2099_enemy_texture.json` and
`reference/spider2099_movie.json`.


**Hunter's Return is implemented in v0.32.0 and corrected in v0.32.1.** Its existing
Webbed Fury 100 XP purchase remains; release A after the dash hit, then tap A for
native eligible recall and a rising rake. Native-unrecallable targets receive
a short physical attempt. R cancels, and B remains manual. The fuller model
keeps the current atlas, rig and 516 triangles. Player feel/appearance remain
open; scoped evidence is in `reference/hunters_return.json`.

**Talon Lift is published in v0.33.0** through the guarded publisher.
It retains Power Launch's native 200 XP purchase, event 330 / bit 21 and ownership.
Up+A coils low into an authored rising rake while staying grounded. Hold B for
the native full jump, then Y to catch the launch with real air hits; R cancels.
Native movement, collision, damage and launch resistance stay. No B bypass,
automatic follow-up, new target state or save migration is needed. Agent tests
pass in both directions; player feel/appearance acceptance remains open.

The other five moves below remain **proposals**:

| Native Black purchase | Move / status | Play role |
|---|---|---|
| Webbed Fury | Hunter's Return (implemented) | After a successful ground dash, optional A recalls the struck eligible enemy into an upward rake. Resistant targets get a short physical pursuit attempt. |
| Power Launch | Talon Lift (implemented) | Up+A performs a coiled rising rake; hold B, then Y, to manually catch a susceptible launch. R cancels. |
| Ground Rebound | Predator Rebound | Native Down+A slam can bounce enemies; choose B,Y to catch one or stay grounded. |
| Black Widowmaker | Raking Cross | Late-pause Y branch becomes a low rake, passing heel kick and turning back rake. |
| Poison Pummel | Talon Cyclone | Compact travelling claw/kick extension ends in a rising scissors kick, then offers air hits, spike, slam or owned air R. |
| Super Charge | Predator Wind-Up | Hold Y during pressure to prime a distinct purchased strike, with a visible coiled pose. |
| Quick Charge | Relentless Pursuit | Faster wind-up and one brief carried charge through evade/manual jump; the next eligible attempt spends it, including a miss. |

The proposed full-kit identity is **catch -> carry -> crash -> chase**;
Hunter's Return and Talon Lift implement its opening. The future loop is dash contact -> optional
Return -> Lift -> hold B -> air rake -> native slam -> choose rebound chase
or another grounded string. Against an immovable boss, use direct close strikes,
short pursuit and R exits; no forced launches, recalls or permanent stun. A's
native ground dash, air spike and Down+A slam keep story traversal and do not
require a combat target or charge. Ordinary B, base strings and native/unowned
R remain. New choreography must be continuous and distinct, with native velocity
and collision, valid targets, interruption/room/form cleanup and preserved buys.

Possible refinements for discussion: a wall-to-target pounce variant within
Raking Cross, and brief crimson talon/eye cues showing a banked charge. Neither
is implemented or an extra Red skill. A wall route needs its own native collision
proof and cannot commandeer barrier dash/slam inputs. The player's first-skill
request supersedes the older Cross-first prototype order. The next-skill request
then selects Lift. Review both implemented moves before another proposed move.
The full dated pitch remains archived under this document's 2099 heading.

