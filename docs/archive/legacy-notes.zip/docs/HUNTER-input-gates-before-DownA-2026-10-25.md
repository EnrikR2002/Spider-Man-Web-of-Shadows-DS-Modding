**Gates before the first slice** (lab only, no release):

1. **Code space:** the 32 KiB kit stays exact. Give 2099 its own guarded
   code/state block, as v0.31.0's autoload extension page did; this deliberately
   extends the kit contract.
2. **Shop:** move the native Black list into the new block (as v0.10.0 moved
   Red's), append the seven rows with appended strings, and keep the native
   rows' bits, events and dependencies exact.
3. **Inputs:** X shared safely with native prompts; held X/Y readable from the
   kit's key words; Down+Y next to a downed enemy distinguished from native
   Down+Y; air X free.
4. **Black-only animation:** route Black-form actions to appended clips. Air
   string actions are shared with Red; GroundAttack15 is shared; G11/16/17 have
   m6.xbd users and are not spare.
5. **Bosses:** a Perch-style velocity follow for Boarding, plus a class-specific
   target adapter for native mini-bosses. Start on the Conductor.
6. **Tier visuals and healing** (before the capstone): a switchable material
   palette in the player draw adapter, partial-segment HUD drawing, and whether
   damage drops combo tiers.

