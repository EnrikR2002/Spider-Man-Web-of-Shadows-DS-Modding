**14. Apex Predator (new).** Passive. 2099 scraps instead of evading, so the
meter both raises his power and keeps him in the fight, the way Red's Momentum
(speed by tier) and Overclock (tier-5 web shot) reward Red. It reads the native
combo tier every update; effects and visuals stack by tier and vanish the moment
the tier drops. It never spends the meter and adds no damage beyond native tier
scaling.

| Tier | Effect | Visual (must read at native scale) |
|---|---|---|
| 0-1 | None | Normal navy/red suit |
| 2+ | **Fast Hunt:** Black attacks and 2099 moves play at 1.10x | Eye lenses and talon tips light up red |
| 3+ | **Heavy Line:** Web Yank and Reel In also catch up to two more enemies in a narrow lane along the line and drag them in together; each arrival takes one light knockdown. **Shockwave Talons:** every 2099 ender (Rundown's last link, Talon Lift, Freefall, Talon Line's hook, Shredder's ender, Meteor Catch, Roof Pin's kick, Wing Ripper) also knocks down every other standing enemy within about 14 units; heavy targets take one stagger | Web lines turn red; chest spider and shoulder panels brighten red |
| 4+ | Fast Hunt rises to 1.20x | Red accents pulse slowly |
| 5 | **Feeding Frenzy:** a little life steal (below) | The whole suit glows red with a slow pulse; the HUD health bar flashes on each heal |

**Feeding Frenzy.** At tier 5, every point of HP Miguel removes from an enemy or
boss (native and kit-built hits alike) adds 5% of it to a hidden heal bank.
Each time the bank holds a quarter health unit (1024 of a unit's 4096), restore
it through the native clamped health setter. About 13 to 20 ordinary hits
restore one segment of the roughly six-segment bar. Caps: at most one health unit per 300
updates; no healing at zero HP, during the near-death minigame or above max.
The bank keeps its contents when the tier drops but fills only at tier 5.
Healing is not a hit, so it does not break rule 6. Life steal was chosen over
heal-on-kill (no sustain in boss fights) and damage reduction (rewards
passivity): it pays for aggression against mobs and bosses alike.

Open questions for the capstone lab:

- Does the HUD draw partial segments? If not, restore whole units so every heal
  is visible.
- Does taking a hit drop combo tiers (TECHNICAL notes a native penalty path
  that subtracts two tiers, trigger unconfirmed)? If so, tier 5 may vanish just
  when healing matters: move Feeding Frenzy to tier 4 before raising its rate.
- In Black form the purple HUD bar shares palette colours 29..31 with the combo
  meter, so a heal flash tints both; that is acceptable.
- Suit glow: pre-bake one palette per tier into the 2099 texture and let the
  existing player draw adapter (`spider2099_visual`) select it. If no material
  palette field can be switched, fall back to red web lines plus HUD tint.

