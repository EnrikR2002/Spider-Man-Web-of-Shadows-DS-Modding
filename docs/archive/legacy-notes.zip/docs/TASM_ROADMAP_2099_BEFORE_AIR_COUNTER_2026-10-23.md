## Spider-Man 2099: Black-slot rework

The player's 2026-10-22 appearance request supplies an Across the Spider-Verse
reference and explicitly removes the red web cape. They like the prior 2099
overall. This supersedes the earlier classic foundation/larger-cape direction.
The first 2026-10-23 request selects Hunter's Return and a more muscular body.
The next-skill request activates Talon Lift; the remaining five moves stay proposals.
The latest request adds height/neon red webs and a film-based design reassessment.
The previous section, including the earlier move roles, is retained byte for byte
in the verified archive as `docs/TASM_ROADMAP_2099_PRE_FILM_2026-10-23.md`.

Published v0.30.3 keeps the guarded shared-model selector and native Red list,
with Black wearing the requested cape-free navy/red movie-inspired appearance.
That appearance is the foundation for v0.32's fuller chest/arms and two private
Hunter motion clips; other native clips remain. The v0.30.3 release
also changes the shared Midnight enemy atlas from 32 KiB direct color to 8 KiB I4.
Three live enemy materials bind in the crowded Terminal capture, while the hero
retains I8. One mixed scene establishes that scene's texture binding, not
all-room residency, player visual acceptance or DeSmuME pacing. Both releases
retain native controls, ownership/progression and previous chapter work. Details
and scope are in `reference/spider2099_enemy_texture.json` and
`reference/spider2099_movie.json`.


**Hunter's Return is implemented in v0.32.0 and corrected in v0.32.1.** Its existing
Webbed Fury 100 XP purchase remains; release A after the dash hit, then tap A for
native eligible recall and a rising rake. Native-unrecallable targets receive
a short physical attempt. R cancels, and B remains manual. The fuller model
keeps the current atlas, rig and 516 triangles. Player feel/appearance remain
open; scoped evidence is in `reference/hunters_return.json`.

**Talon Lift is published in v0.33.0** through the guarded publisher.
It retains Power Launch's native 200 XP purchase, event 330 / bit 21 and ownership.
Up+A coils low into an authored rising rake while staying grounded. Hold B for
the native full jump, then Y to catch the launch with real air hits; R cancels.
Native movement, collision, damage and launch resistance stay. No B bypass,
automatic follow-up, new target state or save migration is needed. Agent tests
pass in both directions; player feel/appearance acceptance remains open.

**v0.33.1 appearance release:** the whole animated Black pose is 12.5% taller,
with its feet anchored and the fuller body/cape-free artwork retained. Native
web lines and web-effect tints become bright scarlet. Red retains its height
and original web tints. Collision, attacks, purchases and save progress remain
native; this appearance request does not authorize combat changes.

### Across the Spider-Verse reassessment - 2026-10-23

The screenplay supplies two useful references: the museum's hardlight arm
lasso and exposed fangs, then the train chase's claw grip, waist reel and forceful
surface pin. The train's crane kick belongs to Miles. These support a kit built
around closing distance and controlling contact. See the authors' [screenplay,
printed pp.12-17 and130-133](https://assets.scriptslug.com/live/pdf/scripts/spider-man-across-the-spider-verse-2023.pdf?v=1729114995).

Supervising animator Daniel Pozo describes research into an intimidating, large
physique using bodybuilder references. That supports the stronger silhouette;
it does not prescribe slow inputs. [Pozo's interview](https://www.abc.net.au/news/2023-06-10/spider-man-across-the-spider-verse-animation/102463650).

The practical film vocabulary is strength, explosive agility, gripping claws,
fangs and bright hardlight tethers. The wrist portal system is equipment, not
permission for a teleport attack. Marvel explicitly gives **comics** Miguel
paralyzing fang venom; the film evidence here does not establish its gameplay
duration, repeatable poison damage or a healing mechanic. Keep those outside
the move plan. Avoid claiming a precognitive counter from these scenes.
[Marvel's character profile](https://www.marvel.com/characters/spider-man-2099-miguel-o-hara).

**Design inference:** make him a powerful, acrobatic pursuer: low coil, rapid
diagonal entry, committed body contact and a weighted recovery that R can exit.
Use claws to show grip and red tethers to show tension. Extended pirouettes,
repeated floaty relaunches and a long stationary charging pose would weaken that
identity. This is an interpretation for a playable DS kit, not a claim that the
film supplies these named moves or a particular martial-art system.

The recommendations below supersede the earlier proposed choreography, keeping
the same purchase slots. Only the first two moves are implemented:

| Native Black purchase | Move / status | Reassessed role and decision |
|---|---|---|
| Webbed Fury | Hunter's Return (implemented) | Keep the successful-dash/optional-A catch. It is the clearest tether-and-pursuit fit. Any later motion polish should stress line tension and a forceful catch; preserve resistance and R. |
| Power Launch | Talon Lift (implemented) | Keep the compact coil/rake and manual held-B air catch as a gameplay bridge. It is an adaptation, not a literal film attack; do not add automatic ascent or repeat launches. |
| Ground Rebound | Predator Rebound (deferred) | Emphasize a heavy downward drive and short grounded recovery. Treat the native bounce as an optional opening, not the kit's main recurring spectacle. |
| Black Widowmaker | Raking Cross (deferred) | Best next prototype: low rake into a short crossing pounce/body drive, then a turning claw exit. Drop the decorative passing heel kick. A wall pin needs real collision/release proof; use a grounded drive until that exists. |
| Poison Pummel | Talon Cyclone (deferred; rethink most) | Replace the long rotation/rising-scissors concept with one compact airborne catch, brief claw contact and a downward drive. Working name can remain until selected. Preserve the existing purchase; do not infer a venom status from its native name. |
| Super Charge | Predator Wind-Up (deferred) | A brief loaded pounce/heavy catch with readable shoulder/hip compression. Keep ordinary movement available while priming it; contact and misses need recovery. |
| Quick Charge | Relentless Pursuit (deferred) | Support quick re-entry after one evade/manual jump, spending the carried charge on the next attempt, including a miss. It should reward the player's chase, without automatic tracking or permanent stun. |

The recommended identity is **close/cut off -> tether or catch -> drive/slam ->
re-engage**. Air strings remain a choice after Lift, rather than the required
destination of every attack. Show weight through anticipation, overlap, impact
and recovery while retaining responsive inputs. Qualify continuous paths,
misses, both facings, armor/resistant bosses and native R exits before expanding.

Native ground A dash, air spike, Down+A slam, B, base strings and unowned R keep
their traversal/story roles without a target or charge. No forced boss movement,
teleports, time slowing, new purchases or save expansion. A future pin or air
catch must prove native victim ownership, release on interruption/death/room
changes and ordinary collision first. Review the two shipped moves before
activating any further proposal.

