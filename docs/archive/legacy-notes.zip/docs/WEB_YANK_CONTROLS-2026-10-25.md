# Web Yank before pure-pull controls

### Controls in Black form (all rows owned)

| Input | Action |
|---|---|
| Y, Y, Y... | Native Black string; late-pause branches become Talon Line and Shredder |
| Hold Y, release | Talon Pounce (Up held at release aims high) |
| Air Y | Sky Rake |
| Down+Y next to a downed enemy | Roof Pin (otherwise native Down+Y) |
| A on the ground | Native Power Dash; A again after a dash hit = Rundown |
| Up+A on the ground | Talon Lift |
| Air A | Native Hammer Spike; Meteor Catch when an airborne enemy is in reach |
| Air Down+A | Native Hammer Slam with Freefall's height bonus |
| X, no lift/lever/grate prompt in reach | Web Yank (Up+X yanks upward) |
| Air X | Reel In |
| Web Yank zip, Up-pounce or jump into a boss while holding toward it | Boarding; while riding, Y rakes and A is Wing Ripper |
| R | Native evade; lets go of any 2099 move |
| B | Native jump, swing and Enemy Kick-Off |

Native X prompts (lift, lever, grate) always win over Web Yank.


**8. Web Yank (new; pull refined after the 2026-10-24 rejection).** Ground X
with no native prompt ties a scarlet line to the nearest enemy ahead within
about 45 units. A firm grounded reel keeps it upright and brings it six units
in front of Miguel; actual arrival starts the authored talon rake. Up+X launches
at that strike. Within eight units, skip the pull and rake immediately. Let the
player flow into a normal follow-up without waiting through a floor bounce.
Heavy: Miguel zips to the target by native velocity and strikes; holding toward
it with Boarding owned starts Boarding once that later skill ships. The original
pipeline-proof pull design is archived before replacement.

**9. Reel In (new, requires Web Yank).** X in the air: tie the nearest enemy
below or ahead and pull it up to Miguel's height to extend or restart an air
combo. Heavy: Miguel zips to it. Lab question: whether a built yank toward an
airborne player lifts the enemy, or a timed launch is needed instead.

