# Retired Spider-Man 2099 Black combat designs

Archived 2026-10-23 from docs/TASM_ROADMAP.md; the current design is that
document's "Combat: the Hunter" section. Text below is verbatim from the named
revisions except that each heading is demoted one level. Neither design was
implemented.

## 2026-10-22 catch/carry/crash/chase proposal (revision f5d1417)

Source: docs/TASM_ROADMAP.md at f5d1417ac7077e625785ee18315814b5e2894f7d. Superseded 2026-10-23 by Hunter
revision 1 at the player's request for a film-faithful Miguel O'Hara.

### Spider-Man 2099: Black-slot rework

The player's latest 2026-10-22 request supplies an Across the Spider-Verse
reference and explicitly removes the red web cape. They like the prior 2099
overall. This supersedes the earlier classic foundation/larger-cape direction;
the seven-move combat pitch remains deferred design work.

Published v0.30.3 keeps the guarded shared-model selector and native Red list,
with Black wearing the requested cape-free navy/red movie-inspired appearance.
The 2099 model and native motion remain unchanged from v0.30.2. The same release
also changes the shared Midnight enemy atlas from 32 KiB direct color to 8 KiB I4.
Three live enemy materials bind in the crowded Terminal capture, while the hero
retains I8. One mixed scene establishes that scene's texture binding, not
all-room residency, player visual acceptance or DeSmuME pacing. Both releases
retain native controls, ownership/progression and previous chapter work. Details
and scope are in `reference/spider2099_enemy_texture.json` and
`reference/spider2099_movie.json`.


The historical seven-skill pitch remains a **proposal**, not implemented moves:

| Native Black purchase | Proposed move | Play role |
|---|---|---|
| Webbed Fury | Hunter's Return | After a successful ground dash, optional A recalls the struck eligible enemy into an upward rake. Resistant targets get a short physical pursuit attempt. |
| Power Launch | Talon Lift | Up+A performs a coiled rising rake; B manually follows a susceptible launch. |
| Ground Rebound | Predator Rebound | Native Down+A slam can bounce enemies; choose B,Y to catch one or stay grounded. |
| Black Widowmaker | Raking Cross | Late-pause Y branch becomes a low rake, passing heel kick and turning back rake. |
| Poison Pummel | Talon Cyclone | Compact travelling claw/kick extension ends in a rising scissors kick, then offers air hits, spike, slam or owned air R. |
| Super Charge | Predator Wind-Up | Hold Y during pressure to prime a distinct purchased strike, with a visible coiled pose. |
| Quick Charge | Relentless Pursuit | Faster wind-up and one brief carried charge through evade/manual jump; the next eligible attempt spends it, including a miss. |

The identity is **catch -> carry -> crash -> chase**: dash contact -> optional
Return -> Lift -> manual B -> air rake -> native slam -> choose rebound chase
or another grounded string. Against an immovable boss, use direct close strikes,
short pursuit and R exits; no forced launches, recalls or permanent stun. A's
native ground dash, air spike and Down+A slam keep story traversal and do not
require a combat target or charge. Ordinary B, base strings and native/unowned
R remain. New choreography must be continuous and distinct, with native velocity
and collision, valid targets, interruption/room/form cleanup and preserved buys.

Possible refinements for discussion: a wall-to-target pounce variant within
Raking Cross, and brief crimson talon/eye cues showing a banked charge. Neither
is implemented or an extra Red skill. A wall route needs its own native collision
proof and cannot commandeer barrier dash/slam inputs. First mechanical prototype
should establish one satisfying Cross/cancel/turn sequence before expanding.
The full dated pitch remains archived under this document's 2099 heading.

## 2026-10-23 Hunter revision 1 (revision 8ecf4b4)

Source: docs/TASM_ROADMAP.md at 8ecf4b41d5860ad8a78e2e1139a215d7e7b9ce19. The player's same-day review:
better overall, but pin/pound dominated into a one-trick style, pins had no
boss answer, there was no webbing and no air combo, and seven rows were an
unnecessary limit. Superseded by Hunter revision 2.

#### Combat: the Hunter (design, 2026-10-23)

On 2026-10-23 the player asked for Black to play and fight as close as possible
to Miguel O'Hara in *Across the Spider-Verse*, and to be fun enough to make them
want to play it. This **replaces** the 2026-10-22 "catch -> carry -> crash ->
chase" proposal. Nothing below is implemented, agent-tested or player-confirmed.

**What the film shows.** Miguel is not an acrobat. He is big, serious and
relentless: he leads the whole Spider Society after Miles, runs him down across
Nueva York and ends the chase by pinning Miles to the roof of a speeding train.
He is reportedly animated on ones,
the smoothest motion in the film, so his weight comes from fluid anticipation
and follow-through rather than stiffness
([film](https://en.wikipedia.org/wiki/Spider-Man:_Across_the_Spider-Verse),
[chase](https://intothespiderverse.fandom.com/wiki/Hunt_for_Miles_Morales)).

**Identity: Red never stands still; 2099 never lets go.** Red slips around a
crowd and resumes. 2099 picks one target, closes the gap, seizes it and turns
its body into a weapon against the rest. The loop is
**hunt -> seize -> punish -> hurl -> hunt**.

- Each move is a different physical verb: pounce, tackle, throw, dive, rake,
  pin, chain. No move is "another rake with a talon trail".
- Power reads through mass: a low coiled crouch, shoulder-first contact, carried
  bodies, floor impacts and enemies flying into other enemies. No freezes, slow
  motion or player teleports.
- Holding a target is the risk. While Miguel pins or hoists, the others can hit
  him (native hurt interrupts). Choosing when to pin and when to throw is the skill.
- R always lets go and evades natively. 2099 does not borrow Red's
  combo-keeping Reflex; his continuity comes from Relentless (below).

**Native foundation stays exact.** Ground A Power Dash is the tackle, air A
Hammer Spike the dive, air Down+A Hammer Slam the crash. Their inputs, movement,
barrier/floor story use, B, base Y strings, unowned R and shared upgrades stay
native and never need a target or charge. Purchases change what happens **on
enemy contact** and add follow-ups. Unowned rows keep native behavior; no
ownership moves, and native dependencies remain (Widowmaker before Pin & Pound,
Super Charge before Relentless).

| Native purchase (bit) | 2099 move | Input | Ordinary enemies | Bosses and resistant enemies |
|---|---|---|---|---|
| Webbed Fury (20) | **Rundown** | A again after a Power Dash hit; up to two more links | Each link is a real dash at the tumbling target or the next enemy ahead; the last drives its target into the floor. Pinball through a crowd. | Shoulder check that stops on contact; the boss never moves. |
| Power Launch (21) | **Collar Toss** | Grounded Up+A | Seize the nearest enemy in front, hoist it overhead and throw it along the held direction: forward bowls it through the crowd, back turns and hurls it behind, Down slams it at Miguel's feet into a pin. | Two-hand overhead hammer strike. |
| Ground Rebound (22) | **Freefall** | Native Down+A slam | Head-first, talons-first dive. Impact strength and radius grow with drop height up to a cap. Bystanders keep the native bounce; the enemy under Miguel stays down for Pin & Pound. | Height-scaled direct damage; no bounce. |
| Black Widowmaker (23) | **Talon Line** | Y,Y,Y, pause, Y,Y | Three slashes that walk Miguel through his target, then a hook: the talons catch it and drag it across his body, flinging it behind him. Back hooks the enemy behind instead. | Two close slashes; no drag. |
| Poison Pummel (24) | **Pin & Pound** | Y,Y,Y, pause, repeated Y | The signature. Miguel bears the enemy down, plants a knee and talons, and hammers once per Y up to a cap. Direction+Y or the cap ends it with a throw that way; R lets go. | Talon cling: close rakes per Y without moving the boss; R exits. |
| Super Charge (25) | **Talon Pounce** | Hold Y, release | Miguel coils low; release fires a long flat leap, talons first, at the enemy ahead (range grows with the coil, capped). A hit tackles and lands on it: Pin & Pound if owned, otherwise a knockdown. | Pounce strike only. |
| Quick Charge (26) | **Relentless** | Passive | Halves the coil. Y can be held through any 2099 finisher (Rundown's last link, Collar Toss, Freefall, Talon Line's hook, Pin's throw), so Pounce fires the instant it ends and the hunt never resets. One stored pounce; hurt or R clears it. | Same. |

**Routes this should make possible** (purchases and nearby targets required):

- **Nueva York chase:** Pounce the nearest -> Pin & Pound -> throw into the pair
  behind -> held-Y pounce onto the one getting up -> Talon Line hook -> Rundown
  through the rest.
- **Bowling:** Collar Toss into a group -> Power Dash Rundown through the falling
  bodies -> wall climb -> Freefall onto the pile.
- **Dive bomb:** climb a Hive shaft or Crane roof -> Freefall from the ceiling ->
  Pin & Pound the enemy left under him -> throw.
- **Tag team:** Red cocoons a group with web or Dragnet -> L -> Collar Toss a
  cocoon into the rest. Needs a cocoon-throw lab; Vortex stays Red-only.
- **Boss:** Pounce strike -> Talon Line slashes -> R out of a telegraph -> climb
  -> high Freefall -> Pounce back in. No forced boss movement, permanent stun or
  invented armor breaks.

**Starting feel targets** (tuning starts here; the player's verdict decides):
Pounce crosses about 25 units in under half a second and never passes a wall; a
pin lasts only while Y keeps coming, capped near six pounds; a thrown body
knocks down each enemy it meets once and lands where the D-pad pointed;
Freefall adds nothing below a held jump's height.

**Presentation.** Author every clip with continuous curves at full sample
density, heavy anticipation, shoulder- or talon-led contacts and overlap; no
per-key holds. Poses: a low wide crouch, splayed talons, a body stretched through
the pounce, a head-first dive and a knee-and-talon pin. Optional cue: a brief red
talon/eye accent while Relentless holds a pounce, if the palette path allows.
Use native impact audio; do not rename stock punches as new moves.

**Engineering gates before the first slice:**

1. **Space:** the 32 KiB kit stays exact for Red. 2099 needs its own guarded
   code/state block, as v0.31's autoload page did. That is a deliberate contract
   change; measure headroom first.
2. **Black-only resources:** list the actions/SCA/GMB used by Black string nodes
   5..10, dash, slam, Widowmaker, Pummel and charge. Re-author only Black-only
   ones: GroundAttack15 is shared and G11/16/17 have m6.xbd users.
3. **Hooks:** map dash contact, slam contact, the bit-23 late branch and the
   native hold-Y charge state in the lab. Whether a charge can start from
   idle/run is open; if not, Pounce starts from a held strike.
4. **Body control:** Vortex already steers enemy bodies with bounded native
   velocity and native hit kinds (knockdown 0x1F, far throw 0x24, launch 0x25,
   floor drag 0x26), and a floor hit on a lying enemy re-bounces it. Prove one
   pinned-then-thrown enemy, its boss fallback and its R exit first.

**Build order:** one complete slice at a time, each with a player verdict
before the next.

1. **Pin & Pound** with its throw, boss cling and R exit: the film's signature
   moment and the body-control backend every other move reuses.
2. **Freefall:** the cheapest spectacle; it turns vertical rooms into dive-bomb
   arenas.
3. **Talon Pounce + Relentless:** the glue that keeps the hunt continuous.
4. **Collar Toss + Rundown:** crowd bowling.
5. **Talon Line:** last, because it replaces the most animation.

**From the superseded pitch:** kept native A parity, no forced boss movement, R
exits, a single stored charge, the wall-pounce idea (now a later Pounce variant)
and the crimson cue (now Relentless's cue). Dropped the aerial juggle routes
(Talon Lift, manual-B follow, rebound catch), per-move charged variants and
Raking Cross as the first prototype: they read as comic or Red-style juggling,
not the film's grappling pursuer. The full dated pitch stays in the archive
under this document's 2099 heading.
